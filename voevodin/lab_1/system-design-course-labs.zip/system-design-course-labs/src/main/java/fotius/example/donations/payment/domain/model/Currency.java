package fotius.example.donations.payment.domain.model;

public enum Currency {
    UAH,
    EUR,
    USD
}
