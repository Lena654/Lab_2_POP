package fotius.example.donations.payment.domain.model;

public enum PaymentMethod {
    CARD,
    APPLE_PAY,
    GOOGLE_PAY
}
