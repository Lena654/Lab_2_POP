Import project using _File -> New -> Project from Existing Sources_:

![img](import-project.png)

Select _Import project from external model_ and use _gradle_:

![img](import-project-gradle.png)

Go to settings and enable annotation processing:

![img](enable-annotation-processing.png)

:warning: In case you switch branch or do something to dependencies in order for change to take effect 
use the gradle menu on the right and resycn project:

![img](gradle-resync.png)
